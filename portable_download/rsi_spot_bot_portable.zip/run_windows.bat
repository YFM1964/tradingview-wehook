@echo off
setlocal
echo Installing dependencies...
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
echo Running bot...
py rsi_spot_bot_kucoin_zones_with_volume.py
pause
