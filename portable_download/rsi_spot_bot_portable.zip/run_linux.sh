#!/usr/bin/env bash
set -e
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
python3 rsi_spot_bot_kucoin_zones_with_volume.py
